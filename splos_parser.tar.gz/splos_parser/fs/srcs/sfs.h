/*
 * =====================================================================================
 *
 *       Filename:  sfs.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  04/06/2015 07:26:39 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  kristychen (chenluwen), eallyclw@gmail.com
 *        Company:  where there is a will, there is a way
 *
 * =====================================================================================
 */

#ifndef __SFS_H__
#define __SFS_H__

struct sfs_mem_ctrl * sfs_init();
int return_sfs_mem_ctrl();

#endif //__SFS_H__
