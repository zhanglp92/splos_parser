#include "share_fs.h"

int share_fs()
{
	int shid;
	void *sharem1 = NULL;
	void *sharem2 = NULL;
	void *sharem3 = NULL;
	void *sharem4 = NULL;
	void *sharem5 = NULL;
	void *sharem6 = NULL;
	void *sharem7 = NULL;

	shid = shmget((key_t)65321, (size_t)1014*1024, 0600|IPC_CREAT);
	sharem1 = shmat(shid, NULL, 0);
	shid = shmget((key_t)65322, (size_t)1014*1024, 0600|IPC_CREAT);
	sharem2 = shmat(shid, NULL, 0);
	shid = shmget((key_t)65323, (size_t)1014*1024, 0600|IPC_CREAT);
	sharem3 = shmat(shid, NULL, 0);
	shid = shmget((key_t)65324, (size_t)1014*1024, 0600|IPC_CREAT);
	sharem4 = shmat(shid, NULL, 0);
	shid = shmget((key_t)65325, (size_t)1014*1024, 0600|IPC_CREAT);
	sharem5 = shmat(shid, NULL, 0);
	shid = shmget((key_t)65326, (size_t)1014*1024, 0600|IPC_CREAT);
	sharem6 = shmat(shid, NULL, 0);
	shid = shmget((key_t)65327, (size_t)1014*1024, 0600|IPC_CREAT);
	sharem7 = shmat(shid, NULL, 0);

	Ctrl = (struct sfs_mem_ctrl *) sharem1;
	Ctrl->superblock = (struct sfs_superblock *)sharem2;
	Ctrl->blockmap = (struct sfs_blockbitmap *)sharem3;
	Ctrl->blockmap->map = (unsigned int *)sharem4;
	Ctrl->inodemap = (char *)sharem5;
	Ctrl->inodetable = (struct sfs_inode *)sharem6;
	Ctrl->root = (struct dir_entry *)sharem7;

	ide_init_block("/tmp/file.txt");
	
	return 0;
}


