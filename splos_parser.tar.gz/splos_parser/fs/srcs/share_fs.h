#ifndef __FILE_H__
#define __FILE_H__

#include "init.h"
#include "fileinterface.h"
#include "dev.h"
#include <stdlib.h>
#include <stdio.h>
#include <sys/shm.h>

int share_fs();
#endif
