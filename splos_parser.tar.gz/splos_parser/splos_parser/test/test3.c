/*************************************************************************
	> File Name: test.h

	> Author: zhanglp

	> Mail: zhanglp92@gmail.com

	> Created Time: 2015年05月09日 星期六 16时17分20秒

	> Description: 
 ************************************************************************/

void test_fun3 (void)
{
    int a = 10;
    a += 10;
}
