void test_fun2 (void)
{
    int a = 10;
    a += 10;
}
