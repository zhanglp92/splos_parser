/*************************************************************************
	> File Name: conf.h
	> Author: 
	> Mail: 
	> Created Time: 2015年05月20日 星期三 16时34分26秒
 ************************************************************************/

#ifdef LOF_FILE
LOG_FILE ("/tmp/result.txt")
#endif

#ifdef FILE_FIX
FILE_FIX (_H,	".h")
FILE_FIX (_PC,	".pc")
#endif

