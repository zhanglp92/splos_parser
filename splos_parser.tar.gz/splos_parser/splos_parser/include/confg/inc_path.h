#if defined(INC_PATH)
INC_PATH ("/tmp")
INC_PATH ("/home")
INC_PATH ("../lib/splos_module")
#endif
